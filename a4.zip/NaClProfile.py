import base64
import nacl.utils
from nacl.public import PrivateKey, PublicKey, Box
from Profile import Profile, Post, DsuFileError, DsuProfileError
from NaClDSEncoder import NaClDSEncoder



class NaClProfile(Profile, Post):
    def __init__(self):
        """
        public_key:str
        private_key:str
        keypair:str
        enc:str
        """
        self.keypair = None
        self.public_key = None
        self.private_key = None
        self.enc = None

    def generate_keypair(self) -> str:
        """
        Generates a new public encryption key using NaClDSEncoder.
        This method should use the NaClDSEncoder module to generate a new keypair and populate
        the public data attributes created in the initializer.

        :return: str    
        """
        en = NaClDSEncoder()
        en.generate()
        self.keypair = en.keypair
        self.public_key = en.public_key
        self.private_key = en.private_key
        return en.keypair

    def import_keypair(self, keypair: str):
        """
        Imports an existing keypair. Useful when keeping encryption keys in a location other than the
        dsu file created by this class.

        This method uses the keypair parameter to populate the public data attributes created by
        the initializer. 
        """
        self.keypair = keypair
        self.public_key = self.keypair[:44]
        self.private_key = self.keypair[44::]

    def add_post(self, p):
        """
        Before a post is added to the profile, it should be encrypted.

        To call the method you are overriding as it exists in the parent class with built-in super keyword:
        """
        super(NaClProfile,self).__init__()
        a = self.encrypt_entry(p['entry'],self.public_key)
        self.enc = a
        a = Post(a)
        super(NaClProfile,self).add_post(p)
        
    def get_posts(self):
        """
        Using built-in super keyword, the program calls posts and decrypts entry.
        :return Post
        """
        c = super().get_posts()
        c[0]['entry'] = self.decrypt_entry(self.private_key,self.public_key,self.enc)
        return c

    def save_profile(self, p):
        """
        save information onto given Path
        """
        hold = super().get_posts()
        a = Profile(username = self.public_key, password = self.private_key)
        a._posts = hold
        a.save_profile(p)
        
    def load_profile(self, p):
        """
        load information from the given path with add_post
        """
        svr = Profile()
        svr.load_profile(p)
        self.public_key = svr.username
        self.private_key = svr.password
        a = svr.get_posts()[0]
        self.add_post(a)

    def encoder(self,key):
        """
        encode keys
        """
        return base64.b64decode(key.encode('utf-8'))
    
    def encrypt_entry(self, entry:str, public_key:str) -> bytes:
        """
        encrypt given message
        """
        a = PrivateKey(self.encoder(self.private_key))
        b = PublicKey(self.encoder(public_key))
        nonce = nacl.utils.random(Box.NONCE_SIZE)
        box = Box(a,b)
        return base64.b64encode(box.encrypt(bytes(entry, "utf-8"))).decode('utf-8')
    
    def decrypt_entry(self, private:str, public:str, entry) -> str:
        """
        decrypt given message
        """
        a = PrivateKey(self.encoder(private))
        b = PublicKey(self.encoder(public))
        nonce = nacl.utils.random(Box.NONCE_SIZE)
        box = Box(a,b)
        try:
            return box.decrypt(base64.b64decode(entry.encode('utf-8'))).decode('utf-8')
        except nacl.exceptions.CryptoError:
            print("Wrong Username or Password!")
            quit()





