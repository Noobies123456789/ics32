import socket
from ds_protocol import join

def send(server:str, port:int, username:str, password:str, key:str, message:str, bio:str=None):
    """
    connects to given server and port with username,password, and token
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.connect((server, port))

        send = client.makefile('w')
        recv = client.makefile('r')

        print("client connected to {HOST} on {PORT}")

        while True:
            a = join(username,password,key)
            send.write(a + '\r\n')
            send.flush()

            srv_msg = recv.readline()

            print("Response",srv_msg)
            break

    

