
import socket
import json
from collections import namedtuple

def join(username, password,key):
  """
  change format to json
  """
  x = {"join":{"username":username,"password":password,"token":key}}
  x = json.dumps(x)
  return x
