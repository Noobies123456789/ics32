import urllib, json
from urllib import request,error
import socket

class music():
    
    def __init__(self, c = None, api= None):
        '''assign keywords to variables inside class'''
        self.name = c
        self.apikey = api
        self.topalbum = None
        self.topartist = None
        self.main()
    
    def main(self) -> None:
        search = input("topalbum or topartist?") #ask user two choices.
        if search == 'topalbum': #if chosen, searches topalbum of a given artist
            url = "http://ws.audioscrobbler.com/2.0/?method=artist.gettopalbums&artist="+self.name+"&api_key="+self.apikey+"&format=json"
        if search == 'topartist': #if chosen, give topartist
        url = "http://ws.audioscrobbler.com/2.0/?method=chart.gettopartists&artist="+self.name+"&api_key="+self.apikey+"&format=json"

        response = None
        connect = None
        r = None
        try:
            connect = urllib.request.urlopen('https://www.apple.com') #check if internet connection exists
        except:
            print("No internet connection")
            exit()
        try:
            response = urllib.request.urlopen(url)
            json_results = response.read()
            r = json.loads(json_results)
        except ConnectionError:
            print("Website does not exist")
            exit()
        except urllib.error.URLError as a:
            print("Invalid APIKEY or URL. Check again")
            exit()
        except urllib.error.HTTPError as e:
            print('Failed to download contents of URL')
            if e.code == 404:
                print("Forbidden url")
                exit()
            if e.code == 503:
                print('Overloaded website. Try again later')
                exit()
            

        finally:
            if response != None:
                response.close()
    
        if r is not None:
            self.topartist = r['artists']['artist'][0]['name'] #from json, add artist at the top to topartist
            self.topalbum = r['topalbums']['album'][0]['name'] #from json, add album at the top to topalbum

    def set_apikey(self, apikey:str) -> None:
        self.apikey = apikey

    def transclude(self, message:str) -> str:
        '''
        Replaces keywords in a message with associated API data.
        :param message: The message to transclude
	
        :returns: The transcluded message
        '''
        return message.replace('@LastFM',self.topartist)
        #change the word @[keyword] in message to a different value

        
