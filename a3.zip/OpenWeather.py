import urllib, json
from urllib import request,error
import socket

class OpenWeather():
    
    def __init__(self, c = None, cc = None, api= None):
        '''assign keywords to variables inside class'''
        self.city = c
        self.country = cc
        self.apikey = api
        self.temperature = None
        self.high_temperature = None
        self.low_temperature = None
        self.longitude = None
        self.latitude = None
        self.description = None
        self.humidity = None
        self.sunset = None
        self.main()
    
    def main(self) -> None:
        url = f"https://api.openweathermap.org/data/2.5/weather?q={self.city},{self.country}&appid={self.apikey}"
        response = None
        connect = None
        r = None
        try:
            connect = urllib.request.urlopen('https://www.apple.com') #check if there's the internet
        except:
            print("No internet connection")
            exit()
        try:
            response = urllib.request.urlopen(url)
            json_results = response.read() 
            r = json.loads(json_results)
        except ConnectionError: #check if the website exists
            print("Website does not exist")
            exit()
        except urllib.error.URLError as a:
            print("Invalid APIKEY or URL. Check again")
            exit()
        except urllib.error.HTTPError as e:
            print('Failed to download contents of URL')
            if e.code == 404:
                print("Forbidden url")
                exit()
            if e.code == 503:
                print('Overloaded website. Try again later')
                exit()
            

        finally:
            if response != None:
                response.close()
    
        if r is not None:
            self.temperature = r['main']['temp'] #from json, add to temperature value in class
            self.high_temperature = r['main']['temp_max'] #from json, add to maximum temperature value in class
            self.low_temperature = r['main']['temp_min'] #from json, add to minimum temperature value in class
            self.longitude = r['coord']['lon'] #from json, add to longitude value in class
            self.latitude = r['coord']['lat'] #from json, add to latitude value in class
            self.description = r['weather'][0]['description'] #from json, add to description value in class
            self.humidity = r['main']['humidity'] #from json, add to humidity value in class
            self.sunset = r['sys']['sunset'] #from json, add to sunset time value in class

    def set_apikey(self, apikey:str) -> None:
        self.apikey = apikey
        #TODO: assign apikey value to a class data attribute that can be accessed by class members

    def transclude(self, message:str) -> str:
        '''
        Replaces keywords in a message with associated API data.
        :param message: The message to transclude
	
        :returns: The transcluded message
        '''
        return message.replace('@weather',self.description)
        #change the word @[keyword] in message to a different description
   

