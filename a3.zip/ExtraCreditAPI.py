import urllib, json
from urllib import request,error
import socket

class coins():
    
    def __init__(self,coin, date):
        '''assign keywords to variables inside class'''
        self.coin = coin
        self.date = date
        self.market = None
        self.main()
    
    def main(self) -> None:
        url = "https://api.coingecko.com/api/v3/coins/"+self.coin+"/history?date="+self.date
        response = None
        connect = None
        r = None
        try:
            connect = urllib.request.urlopen('https://www.apple.com') #check internet connection
        except:
            print("No internet connection")
            exit()
        try:
            response = urllib.request.urlopen(url)
            json_results = response.read()
            r = json.loads(json_results)
        except ConnectionError:
            print("Website does not exist")
            exit()
        except urllib.error.URLError as a:
            print("Invalid Name or Date format (dd-mm-yyyy). Check again") 
            exit()
        except urllib.error.HTTPError as e:
            print('Failed to download contents of URL')
            if e.code == 404:
                print("Forbidden url")
                exit()
            if e.code == 503:
                print('Overloaded website. Try again later')
                exit()
            

        finally:
            if response != None:
                response.close()
    
        if r is not None:
            self.market = r['market_data']['current_price']['usd'] #from json, add the price (usd) of given cryptocurrency at given date to self.market 

    def transclude(self, message:str) -> str:
        '''
        Replaces keywords in a message with associated API data.
        :param message: The message to transclude
	
        :returns: The transcluded message
        '''
        return message.replace('@extracredit',self.market)
        #replace @[keyword] with the price of cryptocurrency
