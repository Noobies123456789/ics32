https://stackoverflow.com/questions/49307497/python-tkinter-treeview-add-an-image-as-a-column-value
^^^ centers the window to the middle of the screen

https://stackoverflow.com/questions/43932106/tkinter-how-to-fix-the-window-opening-position-while-letting-the-width-and-heig
^^^ helps place the popup in the center of the screen

Use GUI.py to run the program.
The program will show the messages received only. Messages sent will be seen at the time of sent
And will disappear when selecting another recipient and coming back to this recipient. 
Messages sent will be shown on the recipients' window.