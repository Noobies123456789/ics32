import json
from collections import namedtuple
from ds_client import send
import socket

DataTuple = namedtuple('DataTuple', ['typ','message','token'])

def extract_json(json_msg:str) -> DataTuple:
  '''
  Call the json.loads function on a json string and convert it to a DataTuple object
  '''
  try:
    json_obj = json.loads(json_msg)
    typ = json_obj['foo']
    message = json_obj['bar']['baz']
    token = json_obj['a']['b']['c']
  except json.JSONDecodeError:
    print("Json cannot be decoded.")

  return DataTuple(typ, message, token)
