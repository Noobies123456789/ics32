import socket

def send(server:str, port:int, username:str, password:str, message:str, bio:str=None):

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as c:
            c.connect((server, port)) #connect to port
            print("client connected")
            while True:
                c.sendall(username.encode('utf-8'))
                c.sendall(password.encode('utf-8'))
                c.sendall(message.encode('utf-8'))
                c.sendall(bio.encode('utf-8'))
                srv_msg = c.recv(4096)

                print("Response",srv_username.decode('utf-8'))
