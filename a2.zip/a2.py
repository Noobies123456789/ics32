from pathlib import Path
import os, socket, time
from Profile import Profile, Post, DsuFileError, DsuProfileError
from ds_client import send

#dsu server address = 168.235.86.101
#dsu server port = 2021

def opening(p):
    """Opens L command"""
    for i in p.iterdir():
        if i.is_dir() == False:
            asdf.append(os.path.abspath(i)) #add non-directories to list
    for j in p.iterdir():
        if j.is_dir():
            asdf.append(os.path.abspath(j)) #add directories to list
    return asdf #asdf becomes files first and then directories

def rec(a):
    """Recursively takes path of files into list na"""
    for i in a.iterdir():
        if i.is_dir() == False:
            na.append(os.path.abspath(i)) #if not a directory, add file
    for j in a.iterdir():
        if j.is_dir():
            na.append(os.path.abspath(j)) #if a directory, run the function again
            rec(j)
    return na #returns na with files of main folder and folder name, with
#files from folder underneath those name

def fon(g):
    """Print file only"""
    for i in g.iterdir():
        a = Path(i)
        if a.is_dir() == False:
            print(a)
        elif a.is_dir() == True and val == 1: #if val = 1, then the input has -r
            fon(a) #will recursively search the file

def son(m,a):
    """search for files that has the same name as one is variable a"""
    bol = True
    for i in m:
        if Path(i).name == a:
            bol = False
            return i
    if bol and a != '-s': #if a is -s then the user did not enter a file. It will print Error below
        output = 'No file found named' + a
        return output
            

def exe(m,a):
    """search for files that has the same suffix as one is variable a"""
    bol = True
    for i in m:
        if Path(i).suffix == '.'+a:
            bol = False
            print(i)
    if bol and a != '-e': #if a is -e then the user did not enter a suffix. It will print Error below
        print('No file found with extension', a)

def create(m, a):
    """create a new dsu file with given name a"""
    b = m + '/'+ a + '.dsu' #basically wrote the absolute path in b to create the file
    try:
        Path(b).touch()
        print(os.path.abspath(Path(b)))
    except FileExistsError:
        print("File already exists")

def delete(a):
    """delete the given file"""
    try:
        Path(a).unlink()
        print(a, 'DELETED')
    except FileNotFoundError:
        print("File not found")

def read(a):
    """read the file and output the content. Otherwise prints empty"""
    m = Path(a)
    boolean = True
    string = ''
    if Path(m).exists() and Path(m).suffix == '.dsu':
        with Path(m).open() as f:
            string += f.read().rstrip() #removes the newline at the end of the text
    elif Path(m).exists() and Path(m).suffix != '.dsu':
        print('ERROR')
        boolean = False
    elif Path(m).exists() == False:
        print("ERROR")
        boolean = False

    if len(string) > 0:        
        print(string)
    else:
        if boolean: #if any of the statements ran above, boolean will be false, meaning the string isn't empty
            print('EMPTY')

def psp():
    """asks information to be saved in the dsu file"""
    sv.dsuserver = input('Enter a DSU server\n')
    sv.username = input("Create a username\n")
    sv.password = input("Create a password\n")
    sv.bio = input("Enter a bio\n")
    while True:
        msg = input("Write a Post\n")
        p1 = Post(msg)
        sv.add_post(p1)
        ans = input("Do you want to write another Post? Y/N\n")
        if ans.upper() == 'Y':
            continue
        elif ans.upper() == 'N':
            break
        else:
            print('ERROR! ENTER Y OR N!')
    mmm = son(rec(p), name + '.dsu')
    sv.save_profile(str(mmm))

def lod():
    """takes the information in the given dsu file and return it"""
    svr = Profile()
    svr.load_profile(j[1])
    print('Server:', svr.dsuserver)
    print('username:', svr.username)
    print('password:', svr.password)
    print('bio:', svr.bio)
    print('posts:', svr.get_posts())
    b = input('SEND INFORMATION? Y/N\n')
    while True:
        if b.upper() == 'Y':
            print('sending')
            send(svr.dsuserver, 2021, svr.username, svr.password, svr.bio)
        elif b.upper() == 'N':
            break
        else:
            print('ERROR! ENTER Y OR N!')

while True:
    j = input().split() #puts the values into a list
    length = len(j)
    if length == 1 and j[0] != 'Q' and j[0] != 'S':
        print('ERROR')
    if length == 0:
        raise IndexError("Enter a value!")
    
    #declare variables which are used for recursion and fixing tiny details
    m = []
    ns = []
    asdf = []
    na = []
    name = ''
    lol = []
    count = 0
    z = 0
    val = 0
    sv = Profile()
    bb = None
    
    if length > 2:
        hold = False
        name = j[len(j)-1]
        if name == '-s':
            print('Enter a file to be searched')
            break
        if name == '-e':
            print('Enter a file extension to be searched')
            break

    if length >= 2:
        p = Path(j[1])

    if j[0] == 'L':
        lol = opening(p)
        for a in j:
            if length == 2 and count == 0:
                [print(asd) for asd in lol]
                count = 1
            if a == '-r':
                m = rec(p)
                if length < 4:
                    [print(i) for i in m]
                val = 1
            if a == '-f' and z == 0:
                fon(Path(j[1]))
                z = 1
            if a == '-s':
                if val == 1:
                    print(son(m, name)) #m tells us that it will search from previously recursed files
                else:
                    print(son(lol, name)) #if there is not -r in the input, then it will search for files gotten in L command
            if a == '-e':
                exe(m, name)
    elif j[0] == 'C':
        holding = True
        for b in j:
            if b == '-n':
                create(j[1], name)
                psp()
                holding = False
        if holding and length != 1:
            print('Command Error')
    elif j[0] == 'D' and length != 1:
        delete(j[1])
    elif j[0] == 'R':
        read(j[1])
    elif j[0] == 'O': #load profile if O command is called
        lod()
        
        
    elif j[0] == 'Q':
        print("GOOD BYE")
        break

    





