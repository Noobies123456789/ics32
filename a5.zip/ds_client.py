import socket
from ds_protocol import join, con


def send(server, port:int, username:str, password:str, key:str, message:str, bio:str=None):
    """
    connects to given server and port with username,password, and token
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.connect((server, port))

        send = client.makefile('w')
        recv = client.makefile('r')

        print("client connected to {HOST} on {PORT}")

        while True:
            #b = input('dsdf\n')
            a = join(username,password,key)
            b = con('HoK0ohrER6o/0G9f1s6wj160iTLzE8wWOT47O5yuN1A=', message)
            send.write(a + '\r\n')
            send.flush()
            srv_msg = recv.readline()
            print("Response",srv_msg)
            send.write(b + '\r\n')
            send.flush()

            srv_msg = recv.readline()
            print("Response",srv_msg)
            break

